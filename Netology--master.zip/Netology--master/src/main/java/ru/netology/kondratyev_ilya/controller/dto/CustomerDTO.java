package ru.netology.kondratyev_ilya.controller.dto;

import lombok.Data;

@Data
public class CustomerDTO {
    private final int id;
    private final String name;
}
