package ru.netology.kondratyev_ilya.domain;

public interface ConsolePrintable {
    void printToConsole();
}
